<?php $__empty_1 = true; $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="mb-6 last:mb-0">
        <div class="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg shadow-sm">
            <div class="flex-1">
                <div class="flex items-center space-x-4">
                    <div class="flex-1">
                        <h3 class="text-lg font-medium text-gray-900"><?php echo e($website->name); ?></h3>
                        <p class="text-sm text-gray-600">
                            <a href="<?php echo e($website->url); ?>" target="_blank" class="text-blue-600 hover:text-blue-800">
                                <?php echo e($website->url); ?>

                            </a>
                        </p>
                    </div>
                    <div class="flex items-center space-x-2">
                        <?php if($website->is_active): ?>
                            <span class="px-2 py-1 text-xs font-semibold text-green-800 bg-green-100 rounded-full">
                                Active
                            </span>
                        <?php else: ?>
                            <span class="px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-100 rounded-full">
                                Inactive
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="mt-3 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                        <span class="font-medium text-gray-700">Last Checked:</span>
                        <span class="text-gray-900">
                            <?php echo e($website->last_checked_at ? $website->last_checked_at->format('M d, Y H:i') : 'Never'); ?>

                        </span>
                    </div>
                    <div>
                        <span class="font-medium text-gray-700">Status Code:</span>
                        <span class="text-gray-900">
                            <?php if($website->last_status_code): ?>
                                <?php if($website->last_status_code >= 200 && $website->last_status_code < 300): ?>
                                    <span class="text-green-600"><?php echo e($website->last_status_code); ?></span>
                                <?php elseif($website->last_status_code >= 400 && $website->last_status_code < 500): ?>
                                    <span class="text-yellow-600"><?php echo e($website->last_status_code); ?></span>
                                <?php else: ?>
                                    <span class="text-red-600"><?php echo e($website->last_status_code); ?></span>
                                <?php endif; ?>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </span>
                    </div>
                    <div>
                        <span class="font-medium text-gray-700">Error:</span>
                        <span class="text-gray-900">
                            <?php if($website->last_error): ?>
                                <span title="<?php echo e($website->last_error); ?>">
                                    <?php echo e(Str::limit($website->last_error, 50)); ?>

                                </span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="flex items-center space-x-2 ml-4">
                <a href="<?php echo e(route('websites.edit', $website)); ?>" class="inline-flex items-center px-3 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:bg-gray-50">
                    Edit
                </a>
                <form method="POST" action="<?php echo e(route('websites.destroy', $website)); ?>" class="inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" onclick="return confirm('Are you sure you want to delete this website?')" class="inline-flex items-center px-3 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-700">
                        Delete
                    </button>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="text-center py-12">
        <p class="text-gray-500 text-lg">No websites found.</p>
        <p class="text-gray-400 mt-2">Try adjusting your search criteria.</p>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Arash\Herd\sitechecker\resources\views/websites/partials/website-list.blade.php ENDPATH**/ ?>