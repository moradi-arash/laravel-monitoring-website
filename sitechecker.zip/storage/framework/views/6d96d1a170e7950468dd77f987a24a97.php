<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Add Multiple Websites (Bulk)')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <!-- Instructions -->
                    <div class="bg-blue-50 border border-blue-200 rounded-md p-4 mb-6">
                        <p class="text-sm text-blue-800">
                            Add multiple websites at once. Click 'Add Another Website' to add more entries. Leave unused rows empty.
                        </p>
                    </div>

                    <form method="POST" action="<?php echo e(route('websites.bulk-store')); ?>" class="p-6 space-y-6">
                        <?php echo csrf_field(); ?>
                        
                        <!-- Dynamic Form Container -->
                        <div id="websites-container">
                            <?php
                                $oldWebsites = old('websites', []);
                                $websiteCount = count($oldWebsites) > 0 ? count($oldWebsites) : 3;
                            ?>
                            
                            <?php for($i = 0; $i < $websiteCount; $i++): ?>
                                <?php
                                    $oldWebsites = old('websites', null);
                                    $isPostback = $oldWebsites !== null;
                                    $oldActive = old("websites.$i.is_active");
                                    
                                    // Determine checked state:
                                    // - If no old input exists (first visit), default to checked
                                    // - If old input exists, use the actual old value (null = unchecked, 1 = checked)
                                    $shouldBeChecked = $isPostback ? ($oldActive === '1' || $oldActive === 1) : true;
                                ?>
                                
                                <div class="website-entry border border-gray-200 rounded-lg p-4 mb-4 bg-gray-50" data-index="<?php echo e($i); ?>">
                                    <div class="flex justify-between items-center mb-4">
                                        <h3 class="text-sm font-semibold text-gray-700">Website #<span class="website-number"><?php echo e($i + 1); ?></span></h3>
                                        <button type="button" class="remove-website text-red-600 hover:text-red-800 text-sm font-medium">Remove</button>
                                    </div>
                                    
                                    <div class="space-y-4">
                                        <div>
                                            <label for="websites[<?php echo e($i); ?>][name]" class="block font-medium text-sm text-gray-700">Website Name</label>
                                            <input id="websites[<?php echo e($i); ?>][name]" name="websites[<?php echo e($i); ?>][name]" type="text" value="<?php echo e(old("websites.{$i}.name")); ?>" class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm mt-1 block w-full" />
                                            <?php $__errorArgs = ["websites.{$i}.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                        <div>
                                            <label for="websites[<?php echo e($i); ?>][url]" class="block font-medium text-sm text-gray-700">Website URL</label>
                                            <input id="websites[<?php echo e($i); ?>][url]" name="websites[<?php echo e($i); ?>][url]" type="url" value="<?php echo e(old("websites.{$i}.url")); ?>" class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm mt-1 block w-full" placeholder="https://example.com" />
                                            <?php $__errorArgs = ["websites.{$i}.url"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                        <div>
                                            <label for="websites[<?php echo e($i); ?>][is_active]" class="block font-medium text-sm text-gray-700">Status</label>
                                            <div class="mt-2">
                                                <input type="checkbox" id="websites[<?php echo e($i); ?>][is_active]" name="websites[<?php echo e($i); ?>][is_active]" value="1" <?php echo e($shouldBeChecked ? 'checked' : ''); ?> class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" />
                                                <span class="ms-2 text-sm text-gray-600">Active</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endfor; ?>
                        </div>

                        <!-- Add Another Website Button -->
                        <div class="flex justify-start">
                            <button type="button" id="add-website" class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-700 focus:bg-green-700 active:bg-green-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                </svg>
                                Add Another Website
                            </button>
                        </div>

                        <!-- Form Actions -->
                        <div class="flex items-center gap-4">
                            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('Add All Websites')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                            
                            <a href="<?php echo e(route('websites.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-300 border border-transparent rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest hover:bg-gray-400 focus:bg-gray-400 active:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Get initial count from server-side rendered form
        let websiteCount = document.querySelectorAll('.website-entry').length;

        // Add new website row
        document.getElementById('add-website').addEventListener('click', function() {
            addWebsiteRow();
            updateWebsiteNumbers();
        });

        // Add remove functionality to existing rows
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.remove-website').forEach(button => {
                button.addEventListener('click', function() {
                    const row = this.closest('.website-entry');
                    if (document.querySelectorAll('.website-entry').length > 1) {
                        row.remove();
                        updateWebsiteNumbers();
                    } else {
                        alert('You must have at least one website entry.');
                    }
                });
            });
        });

        // Function to add a new website entry row
        function addWebsiteRow() {
            const container = document.getElementById('websites-container');
            const index = websiteCount;
            
            const row = document.createElement('div');
            row.className = 'website-entry border border-gray-200 rounded-lg p-4 mb-4 bg-gray-50';
            row.setAttribute('data-index', index);
            row.innerHTML = `
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-sm font-semibold text-gray-700">Website #<span class="website-number">${index + 1}</span></h3>
                    <button type="button" class="remove-website text-red-600 hover:text-red-800 text-sm font-medium">Remove</button>
                </div>
                
                <div class="space-y-4">
                    <div>
                        <label for="websites[${index}][name]" class="block font-medium text-sm text-gray-700">Website Name</label>
                        <input id="websites[${index}][name]" name="websites[${index}][name]" type="text" class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm mt-1 block w-full" />
                    </div>
                    
                    <div>
                        <label for="websites[${index}][url]" class="block font-medium text-sm text-gray-700">Website URL</label>
                        <input id="websites[${index}][url]" name="websites[${index}][url]" type="url" class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm mt-1 block w-full" placeholder="https://example.com" />
                    </div>
                    
                    <div>
                        <label for="websites[${index}][is_active]" class="block font-medium text-sm text-gray-700">Status</label>
                        <div class="mt-2">
                            <input type="checkbox" id="websites[${index}][is_active]" name="websites[${index}][is_active]" value="1" checked class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" />
                            <span class="ms-2 text-sm text-gray-600">Active</span>
                        </div>
                    </div>
                </div>
            `;
            
            container.appendChild(row);
            websiteCount++;
            
            // Add remove functionality to the new row
            row.querySelector('.remove-website').addEventListener('click', function() {
                if (document.querySelectorAll('.website-entry').length > 1) {
                    row.remove();
                    updateWebsiteNumbers();
                } else {
                    alert('You must have at least one website entry.');
                }
            });
        }

        // Update website numbers after add/remove
        function updateWebsiteNumbers() {
            const entries = document.querySelectorAll('.website-entry');
            entries.forEach((entry, index) => {
                entry.querySelector('.website-number').textContent = index + 1;
                // Update data-index attribute
                entry.setAttribute('data-index', index);
                
                // Update all input names and IDs to match new index
                const inputs = entry.querySelectorAll('input, label');
                inputs.forEach(input => {
                    if (input.id) {
                        input.id = input.id.replace(/websites\[\d+\]/, `websites[${index}]`);
                    }
                    if (input.name) {
                        input.name = input.name.replace(/websites\[\d+\]/, `websites[${index}]`);
                    }
                    if (input.getAttribute('for')) {
                        input.setAttribute('for', input.getAttribute('for').replace(/websites\[\d+\]/, `websites[${index}]`));
                    }
                });
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Arash\Herd\sitechecker\resources\views/websites/bulk-create.blade.php ENDPATH**/ ?>