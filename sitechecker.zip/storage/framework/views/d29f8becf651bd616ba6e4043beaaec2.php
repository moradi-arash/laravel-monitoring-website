<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Settings')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <?php if(session('status') === 'settings-updated'): ?>
                <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline">Settings updated successfully.</span>
                </div>
            <?php endif; ?>

            <?php if(session('status') === 'cron-settings-updated'): ?>
                <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline">Cron settings updated successfully.</span>
                </div>
            <?php endif; ?>

            <!-- User Telegram Settings Section -->
            <div class="bg-white shadow sm:rounded-lg p-4 sm:p-8">
                <div class="max-w-xl">
                    <h3 class="text-lg font-medium text-gray-900">Telegram Notification Settings</h3>
                    <p class="mt-1 text-sm text-gray-600">Configure your Telegram bot credentials to receive website monitoring alerts.</p>
                    
                    <?php echo $__env->make('settings.partials.update-telegram-settings-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

            <?php if($globalConfig): ?>
            <!-- Global Cron Configuration Section -->
            <div class="bg-white shadow sm:rounded-lg p-4 sm:p-8">
                <div class="max-w-xl">
                    <h3 class="text-lg font-medium text-gray-900">System Configuration</h3>
                    <p class="mt-1 text-sm text-gray-600">Configure system-wide security settings for cron job access.</p>
                    
                    <?php echo $__env->make('settings.partials.update-cron-settings-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Arash\Herd\sitechecker\resources\views/settings/index.blade.php ENDPATH**/ ?>